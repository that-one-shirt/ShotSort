# ShotSort

An Android app that sorts your screenshots with Claude vision.

- **Auto-sorts new screenshots** in the background (MediaStore content trigger + hourly backup).
- **Categorizes, titles, tags, and extracts text** from each screenshot using the Claude API (tool-use for structured JSON).
- **Moves files** into category folders, e.g. `Pictures/Screenshots/Receipts & Orders/` (needs *All files access*).
- **Search** across titles, summaries, tags, and the text inside screenshots; filter by category chips.
- Change a screenshot's category from its detail page (the file moves with it), re-analyze, share, or open in your gallery.

Stack: Kotlin, Jetpack Compose (Material 3), Room, WorkManager, Coil. minSdk 29 (Android 10), targetSdk 35.

## Get the APK

Every push to `main` runs `.github/workflows/build.yml`, which builds the debug APK and publishes it as the `latest` release:

```
https://github.com/<you>/ShotSort/releases/download/latest/ShotSort.apk
```

Open that link on your phone, install (allow "Install unknown apps" for your browser), done. The repo includes a fixed debug keystore, so new builds install over old ones without uninstalling.

Building locally instead: open the folder in Android Studio and hit Run, or `./gradlew assembleDebug`.

## First run

1. **Allow photo access** → pick *Allow all*.
2. **Settings → API key** → paste a key from console.anthropic.com → Save.
3. Choose **Sort all N** (backlog) or **Only new ones**.
4. **Grant All files access** if you want files moved into folders (otherwise ShotSort only tags them).

Default model is `claude-haiku-4-5` (change it in Settings). Each screenshot = one API call with a downscaled JPEG (long edge ≤ 1568 px; very tall scrolling screenshots are cropped to the top portion).

## How it works

| Piece | File |
|---|---|
| Find screenshots directly in any `…/Screenshots/` folder | `media/MediaRepo.kt` |
| Claude call (forced `file_screenshot` tool, category enum) | `ai/ClaudeClient.kt` |
| Discover → analyze → move pipeline | `work/Sorter.kt` |
| Background triggers, notifications | `work/Workers.kt` |
| Room DB + search | `data/Database.kt` |
| UI | `ui/*.kt` |

Moving tries `MediaStore` `RELATIVE_PATH` update first, then falls back to a raw file rename + media scan. Screenshots already inside a category subfolder are never re-processed.

## Notes

- `MANAGE_EXTERNAL_STORAGE` means this is a sideload app; Play Store would reject it without justification.
- The API key is kept in app-private SharedPreferences on the device.
