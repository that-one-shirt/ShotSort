package com.nathanleg.shotsort.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Analysis(
    val category: String,
    val title: String,
    val summary: String,
    val tags: List<String>,
    val text: String,
)

class ApiException(val code: Int, message: String) : IOException(message)

class ClaudeClient(private val apiKey: String, private val model: String) {

    suspend fun analyze(jpeg: ByteArray, categories: List<String>): Analysis {
        val body = buildRequest(Base64.encodeToString(jpeg, Base64.NO_WRAP), categories)
        var attempt = 0
        while (true) {
            try {
                return withContext(Dispatchers.IO) { parse(post(body), categories) }
            } catch (e: ApiException) {
                // Retry rate limits / overload / server errors with backoff.
                val retryable = e.code == 429 || e.code == 529 || e.code >= 500
                if (!retryable || attempt >= 3) throw e
            }
            attempt++
            delay(2000L shl attempt)
        }
    }

    private fun buildRequest(b64: String, categories: List<String>): String {
        val schema = JSONObject()
            .put("type", "object")
            .put(
                "properties", JSONObject()
                    .put(
                        "category", JSONObject()
                            .put("type", "string")
                            .put("enum", JSONArray(categories))
                            .put("description", "The single best-fitting category.")
                    )
                    .put(
                        "title", JSONObject().put("type", "string")
                            .put("description", "Short specific title, max ~8 words, e.g. 'Amazon order – USB-C hub'.")
                    )
                    .put(
                        "summary", JSONObject().put("type", "string")
                            .put("description", "One or two sentences on what the screenshot shows and why someone saved it.")
                    )
                    .put(
                        "tags", JSONObject().put("type", "array")
                            .put("items", JSONObject().put("type", "string"))
                            .put("description", "3-8 lowercase search keywords: app names, people, brands, places, topics.")
                    )
                    .put(
                        "text", JSONObject().put("type", "string")
                            .put("description", "The important visible text (names, numbers, addresses, codes, prices), max ~600 characters.")
                    )
            )
            .put("required", JSONArray(listOf("category", "title", "summary", "tags", "text")))

        val tool = JSONObject()
            .put("name", "file_screenshot")
            .put("description", "Record how this phone screenshot should be filed and found later.")
            .put("input_schema", schema)

        val content = JSONArray()
            .put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", b64)
                )
            )
            .put(
                JSONObject().put("type", "text").put(
                    "text",
                    "This is a screenshot from my Android phone. Categorize it into exactly one of: " +
                        categories.joinToString(", ") +
                        ". Then give it a title, summary, search tags, and the key text. Call file_screenshot."
                )
            )

        return JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("tools", JSONArray().put(tool))
            .put("tool_choice", JSONObject().put("type", "tool").put("name", "file_screenshot"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            .toString()
    }

    private fun post(body: String): JSONObject {
        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching {
                    JSONObject(text).getJSONObject("error").getString("message")
                }.getOrDefault(text.take(200))
                throw ApiException(code, "API $code: $msg")
            }
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(resp: JSONObject, categories: List<String>): Analysis {
        val content = resp.getJSONArray("content")
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "tool_use") {
                val input = block.getJSONObject("input")
                val rawCat = input.optString("category")
                val category = categories.firstOrNull { it.equals(rawCat, ignoreCase = true) }
                    ?: categories.lastOrNull() ?: "Other"
                val tagsJson = input.optJSONArray("tags") ?: JSONArray()
                val tags = (0 until tagsJson.length()).map { tagsJson.optString(it).trim().lowercase() }
                    .filter { it.isNotEmpty() }
                return Analysis(
                    category = category,
                    title = input.optString("title").ifBlank { "Screenshot" },
                    summary = input.optString("summary"),
                    tags = tags,
                    text = input.optString("text"),
                )
            }
        }
        throw IOException("No tool_use block in response")
    }
}
