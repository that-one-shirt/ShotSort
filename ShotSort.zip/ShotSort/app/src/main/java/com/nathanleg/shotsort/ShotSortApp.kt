package com.nathanleg.shotsort

import android.app.Application
import com.nathanleg.shotsort.work.Notifier
import com.nathanleg.shotsort.work.Scheduler

class ShotSortApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannel(this)
        Scheduler.applySettings(this)
    }
}
