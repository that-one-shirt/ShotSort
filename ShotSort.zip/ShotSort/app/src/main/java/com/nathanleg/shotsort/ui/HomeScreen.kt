@file:OptIn(ExperimentalMaterial3Api::class)

package com.nathanleg.shotsort.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nathanleg.shotsort.data.Screenshot
import com.nathanleg.shotsort.data.Status

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onOpen: (Long) -> Unit,
    onSettings: () -> Unit,
    onRequestMedia: () -> Unit,
    onRequestAllFiles: () -> Unit,
) {
    val items by vm.items.collectAsState()
    val counts by vm.counts.collectAsState()
    val pending by vm.pending.collectAsState()
    val errors by vm.errors.collectAsState()
    val running by vm.running.collectAsState()
    val query by vm.query.collectAsState()
    val selected by vm.category.collectAsState()
    val perms by vm.perms.collectAsState()
    val setup by vm.setup.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ShotSort") },
                actions = {
                    IconButton(onClick = { vm.sortNow() }) { Icon(Icons.Filled.Refresh, "Sort now") }
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Settings") }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { vm.query.value = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text("Search text, tags, apps…") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { vm.query.value = "" }) {
                        Icon(Icons.Filled.Close, "Clear")
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
            )

            // ---- setup / onboarding cards ----
            when {
                !perms.read -> SetupCard(
                    "Allow photo access",
                    "ShotSort needs to see your screenshots. Choose \"Allow all\" when asked.",
                    "Allow", onRequestMedia,
                )
                !setup.hasApiKey -> SetupCard(
                    "Add your Claude API key",
                    "Screenshots are categorized by Claude. Paste a key from console.anthropic.com in Settings.",
                    "Open settings", onSettings,
                )
                setup.backlogCount != null -> BacklogCard(
                    count = setup.backlogCount ?: 0,
                    onAll = { vm.chooseBacklog(true) },
                    onNewOnly = { vm.chooseBacklog(false) },
                )
                setup.moveEnabled && !perms.write -> SetupCard(
                    "Allow file access to move screenshots",
                    "To move screenshots into category folders, Android needs \"All files access\". Without it, ShotSort only tags them.",
                    "Grant access", onRequestAllFiles,
                )
            }

            // ---- progress ----
            if (pending > 0 || running) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text(
                        if (pending > 0) "Sorting… $pending left" else "Checking for new screenshots…",
                        style = MaterialTheme.typography.labelMedium,
                    )
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            if (errors > 0) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "$errors couldn't be sorted",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { vm.retryErrors() }) { Text("Retry") }
                }
            }

            // ---- category chips ----
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    FilterChip(
                        selected = selected == null,
                        onClick = { vm.category.value = null },
                        label = { Text("All") },
                    )
                }
                items(counts, key = { it.category }) { c ->
                    FilterChip(
                        selected = selected == c.category,
                        onClick = { vm.category.value = if (selected == c.category) null else c.category },
                        label = { Text("${c.category}  ${c.count}") },
                    )
                }
            }

            // ---- grid ----
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        when {
                            query.isNotBlank() -> "No screenshots match \"$query\"."
                            !perms.read -> "Waiting for photo access."
                            else -> "No sorted screenshots yet. New screenshots will show up here automatically."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(110.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(items, key = { it.id }) { s -> Thumb(s) { onOpen(s.id) } }
                }
            }
        }
    }
}

@Composable
private fun Thumb(s: Screenshot, onClick: () -> Unit) {
    Box(
        Modifier
            .aspectRatio(0.56f)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = s.uri,
            contentDescription = s.title ?: s.displayName,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        val label = when (s.status) {
            Status.PENDING -> "Sorting…"
            Status.ERROR -> "Failed"
            else -> s.title ?: ""
        }
        if (label.isNotEmpty()) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                    .padding(start = 8.dp, end = 8.dp, top = 18.dp, bottom = 6.dp)
            ) {
                Text(
                    label,
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun SetupCard(title: String, body: String, action: String, onAction: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
private fun BacklogCard(count: Int, onAll: () -> Unit, onNewOnly: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Found $count existing screenshots", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            Text(
                "Sort them all now (one Claude API call each), or only sort screenshots you take from now on?",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onAll, enabled = count > 0) { Text("Sort all $count") }
                OutlinedButton(onClick = onNewOnly) { Text("Only new ones") }
            }
        }
    }
}
