package com.nathanleg.shotsort.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

object Status {
    const val PENDING = "PENDING"
    const val DONE = "DONE"
    const val ERROR = "ERROR"
}

@Entity(tableName = "screenshots")
data class Screenshot(
    /** Original MediaStore _ID when first discovered. Stable key even if the file moves. */
    @PrimaryKey val id: Long,
    /** Current content:// uri (may change if the file had to be moved with File APIs). */
    val uri: String,
    val displayName: String,
    /** The screenshots root folder it was found in, e.g. "Pictures/Screenshots/". */
    val rootPath: String,
    /** Where it currently lives. */
    val relativePath: String,
    val dateTaken: Long,
    val status: String = Status.PENDING,
    val category: String? = null,
    val title: String? = null,
    val summary: String? = null,
    val tags: String? = null,
    val text: String? = null,
    val error: String? = null,
    val processedAt: Long = 0,
)

data class CategoryCount(val category: String, val count: Int)

@Dao
interface ScreenshotDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<Screenshot>)

    @Update
    suspend fun update(item: Screenshot)

    @Query("SELECT id FROM screenshots")
    suspend fun allIds(): List<Long>

    @Query("SELECT * FROM screenshots")
    suspend fun all(): List<Screenshot>

    @Query("DELETE FROM screenshots WHERE id IN (:ids)")
    suspend fun deleteIds(ids: List<Long>)

    @Query("SELECT * FROM screenshots WHERE status = 'PENDING' ORDER BY dateTaken DESC LIMIT :limit")
    suspend fun pending(limit: Int): List<Screenshot>

    @Query("SELECT * FROM screenshots WHERE id = :id")
    suspend fun get(id: Long): Screenshot?

    @Query("SELECT * FROM screenshots WHERE id = :id")
    fun observe(id: Long): Flow<Screenshot?>

    @Query("UPDATE screenshots SET status = 'PENDING', error = NULL WHERE status = 'ERROR'")
    suspend fun retryErrors()

    @Query(
        """
        SELECT * FROM screenshots
        WHERE (:category IS NULL OR category = :category)
          AND (:q = '' OR title LIKE '%' || :q || '%' OR summary LIKE '%' || :q || '%'
               OR tags LIKE '%' || :q || '%' OR text LIKE '%' || :q || '%'
               OR category LIKE '%' || :q || '%')
        ORDER BY dateTaken DESC
        """
    )
    fun search(category: String?, q: String): Flow<List<Screenshot>>

    @Query(
        """
        SELECT category, COUNT(*) AS count FROM screenshots
        WHERE status = 'DONE' AND category IS NOT NULL
        GROUP BY category ORDER BY count DESC
        """
    )
    fun categoryCounts(): Flow<List<CategoryCount>>

    @Query("SELECT COUNT(*) FROM screenshots WHERE status = :status")
    fun countByStatus(status: String): Flow<Int>
}

@Database(entities = [Screenshot::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ScreenshotDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shotsort.db"
                ).build().also { instance = it }
            }
    }
}
