package com.nathanleg.shotsort.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.nathanleg.shotsort.R
import com.nathanleg.shotsort.ai.ApiException
import com.nathanleg.shotsort.data.Prefs
import com.nathanleg.shotsort.data.Screenshot
import com.nathanleg.shotsort.ui.MainActivity
import java.io.IOException
import java.time.Duration
import java.util.concurrent.TimeUnit

class SortWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val sorter = Sorter(applicationContext)
        if (!sorter.ready()) return Result.success()
        return try {
            val done = sorter.runAll { isStopped }
            if (inputData.getBoolean(KEY_NOTIFY, false)) Notifier.sorted(applicationContext, done)
            Result.success()
        } catch (e: ApiException) {
            if (e.code == 401 || e.code == 403) Result.failure() else Result.retry()
        } catch (e: IOException) {
            Result.retry()
        }
    }

    companion object { const val KEY_NOTIFY = "notify" }
}

/** Fires whenever MediaStore images change, kicks off a sort, then re-arms itself. */
class ObserverWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        if (!prefs.autoSort) return Result.success()
        Scheduler.sortNow(applicationContext, notify = prefs.notify)
        Scheduler.armObserver(applicationContext, chainAfterCurrent = true)
        return Result.success()
    }
}

object Scheduler {
    private const val SORT = "sort"
    private const val OBSERVER = "observer"
    private const val PERIODIC = "periodic"

    private val network = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun sortNow(ctx: Context, notify: Boolean = false) {
        val req = OneTimeWorkRequestBuilder<SortWorker>()
            .setConstraints(network)
            .setInputData(workDataOf(SortWorker.KEY_NOTIFY to notify))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(SORT, ExistingWorkPolicy.KEEP, req)
    }

    fun armObserver(ctx: Context, chainAfterCurrent: Boolean = false) {
        val constraints = Constraints.Builder()
            .addContentUriTrigger(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true)
            .setTriggerContentUpdateDelay(Duration.ofSeconds(3))
            .setTriggerContentMaxDelay(Duration.ofSeconds(20))
            .build()
        val req = OneTimeWorkRequestBuilder<ObserverWorker>().setConstraints(constraints).build()
        val policy = if (chainAfterCurrent) ExistingWorkPolicy.APPEND_OR_REPLACE else ExistingWorkPolicy.KEEP
        WorkManager.getInstance(ctx).enqueueUniqueWork(OBSERVER, policy, req)
    }

    fun applySettings(ctx: Context) {
        val prefs = Prefs(ctx)
        val wm = WorkManager.getInstance(ctx)
        if (prefs.autoSort) {
            armObserver(ctx)
            val periodic = PeriodicWorkRequestBuilder<SortWorker>(1, TimeUnit.HOURS)
                .setConstraints(network)
                .setInputData(workDataOf(SortWorker.KEY_NOTIFY to prefs.notify))
                .build()
            wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.UPDATE, periodic)
        } else {
            wm.cancelUniqueWork(OBSERVER)
            wm.cancelUniqueWork(PERIODIC)
        }
    }
}

object Notifier {
    private const val CHANNEL = "sorted"

    fun createChannel(ctx: Context) {
        val ch = NotificationChannel(CHANNEL, "Sorted screenshots", NotificationManager.IMPORTANCE_LOW)
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    fun sorted(ctx: Context, items: List<Screenshot>) {
        if (items.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val title = if (items.size == 1) "Sorted into ${items[0].category}"
        else "Sorted ${items.size} screenshots"
        val body = items.take(5).joinToString("\n") { "${it.category}: ${it.title}" }
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle(title)
            .setContentText(items[0].title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(1001, n)
        } catch (_: SecurityException) {
        }
    }
}
