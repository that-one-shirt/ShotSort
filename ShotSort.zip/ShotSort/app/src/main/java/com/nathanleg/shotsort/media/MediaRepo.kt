package com.nathanleg.shotsort.media

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.nathanleg.shotsort.data.Screenshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

class MediaRepo(context: Context) {
    private val ctx = context.applicationContext
    private val cr = ctx.contentResolver
    private val collection: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    // ---------- permissions ----------

    fun hasReadAccess(): Boolean {
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) return true
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return granted(perm)
    }

    /** Needed to move screenshots the system created (we don't own them). */
    fun hasWriteAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    // ---------- discovery ----------

    /**
     * Screenshots sitting directly in a "…/Screenshots/" folder (not in our category
     * subfolders). Covers Pixel (Pictures/Screenshots) and Samsung (DCIM/Screenshots).
     */
    suspend fun findUnsorted(addedAfterSec: Long): List<Screenshot> = withContext(Dispatchers.IO) {
        val out = mutableListOf<Screenshot>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.RELATIVE_PATH,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_ADDED,
        )
        val sel = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.DATE_ADDED} >= ?"
        val args = arrayOf("%Screenshots/", addedAfterSec.toString())
        cr.query(collection, projection, sel, args, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val iRel = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            val iTaken = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val rel = c.getString(iRel) ?: continue
                val taken = if (c.isNull(iTaken)) 0L else c.getLong(iTaken)
                val date = if (taken > 0) taken else c.getLong(iAdded) * 1000
                out += Screenshot(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id).toString(),
                    displayName = c.getString(iName) ?: "screenshot_$id",
                    rootPath = rel,
                    relativePath = rel,
                    dateTaken = date,
                )
            }
        }
        out
    }

    /** Count of existing screenshots (for the first-run "sort backlog?" prompt). */
    suspend fun countUnsorted(): Int = findUnsorted(0).size

    /** MediaStore ids of every image anywhere under a Screenshots folder. */
    suspend fun existingScreenshotIds(): Set<Long> = withContext(Dispatchers.IO) {
        val ids = HashSet<Long>()
        cr.query(
            collection, arrayOf(MediaStore.Images.Media._ID),
            "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?", arrayOf("%Screenshots/%"), null
        )?.use { c ->
            while (c.moveToNext()) ids += c.getLong(0)
        }
        ids
    }

    // ---------- image prep ----------

    /** Downscaled JPEG suitable for the Claude API (long edge <= 1568px). */
    suspend fun jpegForApi(uri: Uri): ByteArray = withContext(Dispatchers.IO) {
        val source = ImageDecoder.createSource(cr, uri)
        var bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val s = min(1f, 1200f / w)
            if (s < 1f) {
                decoder.setTargetSize((w * s).toInt().coerceAtLeast(1), (h * s).toInt().coerceAtLeast(1))
            }
        }
        // Very tall scrolling screenshots: keep the top part so text stays legible.
        val maxH = (bmp.width * 2.3f).toInt()
        if (bmp.height > maxH) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, maxH)
        val longEdge = max(bmp.width, bmp.height)
        if (longEdge > 1568) {
            val s = 1568f / longEdge
            bmp = Bitmap.createScaledBitmap(
                bmp, (bmp.width * s).toInt().coerceAtLeast(1), (bmp.height * s).toInt().coerceAtLeast(1), true
            )
        }
        ByteArrayOutputStream().use { os ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, os)
            os.toByteArray()
        }
    }

    // ---------- moving ----------

    /** Moves the file into <rootPath>/<Category>/ and returns the updated record. */
    suspend fun moveToCategory(s: Screenshot, category: String): Screenshot = withContext(Dispatchers.IO) {
        val newRel = s.rootPath + folderName(category) + "/"
        if (newRel == s.relativePath) return@withContext s
        val uri = Uri.parse(s.uri)

        // 1) Preferred: ask MediaStore to move it (keeps the same id/uri).
        try {
            val cv = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, newRel) }
            if (cr.update(uri, cv, null, null) > 0) return@withContext s.copy(relativePath = newRel)
        } catch (_: Exception) {
            // fall through to the File API path
        }

        // 2) Fallback: raw file rename (works with All-files access / legacy storage).
        val path = dataPath(uri) ?: throw IOException("Couldn't resolve file path for ${s.displayName}")
        val src = File(path)
        if (!src.exists()) throw IOException("File no longer exists: ${s.displayName}")
        val volumeRoot = path.removeSuffix(s.relativePath + src.name).ifEmpty {
            Environment.getExternalStorageDirectory().absolutePath + "/"
        }
        val destDir = File(volumeRoot, newRel)
        if (!destDir.exists() && !destDir.mkdirs()) throw IOException("Can't create ${destDir.path}")
        var dest = File(destDir, src.name)
        var n = 1
        while (dest.exists()) {
            dest = File(destDir, "${src.nameWithoutExtension}_$n.${src.extension}")
            n++
        }
        if (!src.renameTo(dest)) throw IOException("Move failed for ${s.displayName}")
        scan(src.absolutePath) // drops the stale entry
        val newUri = scan(dest.absolutePath) ?: throw IOException("Media scan failed after move")
        s.copy(uri = newUri.toString(), relativePath = newRel, displayName = dest.name)
    }

    private fun dataPath(uri: Uri): String? {
        @Suppress("DEPRECATION")
        val col = MediaStore.Images.Media.DATA
        return cr.query(uri, arrayOf(col), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }

    private suspend fun scan(path: String): Uri? = suspendCancellableCoroutine { cont ->
        MediaScannerConnection.scanFile(ctx, arrayOf(path), null) { _, uri ->
            if (cont.isActive) cont.resume(uri)
        }
    }

    companion object {
        fun folderName(category: String): String =
            category.replace(Regex("[\\\\/:*?\"<>|]"), "-").trim().ifEmpty { "Other" }
    }
}
