package com.nathanleg.shotsort.data

import android.content.Context
import android.content.SharedPreferences

class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("shotsort", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = sp.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    var categories: List<String>
        get() = (sp.getString("categories", null) ?: DEFAULT_CATEGORIES.joinToString("\n"))
            .lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        set(v) = sp.edit().putString("categories", v.joinToString("\n")).apply()

    var moveFiles: Boolean
        get() = sp.getBoolean("move_files", true)
        set(v) = sp.edit().putBoolean("move_files", v).apply()

    var autoSort: Boolean
        get() = sp.getBoolean("auto_sort", true)
        set(v) = sp.edit().putBoolean("auto_sort", v).apply()

    var notify: Boolean
        get() = sp.getBoolean("notify", true)
        set(v) = sp.edit().putBoolean("notify", v).apply()

    /** -1 = user hasn't chosen yet. 0 = sort everything. Otherwise only screenshots added after this epoch-second. */
    var backlogCutoff: Long
        get() = sp.getLong("backlog_cutoff", -1L)
        set(v) = sp.edit().putLong("backlog_cutoff", v).apply()

    companion object {
        const val DEFAULT_MODEL = "claude-haiku-4-5"
        val DEFAULT_CATEGORIES = listOf(
            "Receipts & Orders",
            "Conversations",
            "Social Media",
            "Shopping",
            "Recipes & Food",
            "Code & Tech",
            "Maps & Places",
            "Tickets & Bookings",
            "Memes & Funny",
            "Notes & Info",
            "Other",
        )
    }
}
