@file:OptIn(ExperimentalMaterial3Api::class)

package com.nathanleg.shotsort.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.nathanleg.shotsort.data.Prefs

@Composable
fun SettingsScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
    onRequestMedia: () -> Unit,
    onRequestAllFiles: () -> Unit,
) {
    val p = vm.prefs
    val perms by vm.perms.collectAsState()
    var apiKey by remember { mutableStateOf(p.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(p.model) }
    var categories by remember { mutableStateOf(p.categories.joinToString("\n")) }
    var move by remember { mutableStateOf(p.moveFiles) }
    var auto by remember { mutableStateOf(p.autoSort) }
    var notify by remember { mutableStateOf(p.notify) }

    val save = {
        vm.saveSettings(
            apiKey = apiKey,
            model = model,
            categories = categories.lines().map { it.trim() }.filter { it.isNotEmpty() },
            move = move,
            auto = auto,
            notify = notify,
        )
        onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = { TextButton(onClick = save) { Text("Save") } },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Section("Claude")
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API key") },
                placeholder = { Text("sk-ant-…") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                label = { Text("Model") },
                supportingText = { Text("Default ${Prefs.DEFAULT_MODEL} (fast and cheap). Any vision-capable Claude model works.") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Section("Categories")
            OutlinedTextField(
                value = categories,
                onValueChange = { categories = it },
                label = { Text("One per line") },
                supportingText = { Text("Claude picks exactly one of these. Keep an \"Other\" as a catch-all.") },
                minLines = 6,
                modifier = Modifier.fillMaxWidth(),
            )
            TextButton(onClick = { categories = Prefs.DEFAULT_CATEGORIES.joinToString("\n") }) {
                Text("Reset to defaults")
            }

            Section("Behavior")
            Toggle("Move into category folders", "e.g. Pictures/Screenshots/Receipts & Orders/", move) { move = it }
            Toggle("Auto-sort new screenshots", "Runs in the background whenever you take one", auto) { auto = it }
            Toggle("Notify when sorted", null, notify) { notify = it }

            Section("Permissions")
            PermRow("Photo access", perms.read, onRequestMedia)
            PermRow("All files access (to move files)", perms.write, onRequestAllFiles)
            PermRow("Notifications", perms.notifications, onRequestMedia)

            Section("Maintenance")
            Row {
                OutlinedButton(onClick = { vm.retryErrors() }) { Text("Retry failed") }
                Spacer(Modifier.padding(4.dp))
                OutlinedButton(onClick = { vm.refresh(); vm.sortNow() }) { Text("Rescan now") }
            }

            Spacer(Modifier.height(24.dp))
            Button(onClick = save, modifier = Modifier.fillMaxWidth()) { Text("Save") }
            Spacer(Modifier.height(8.dp))
            Text(
                "Your API key is stored only on this device. Each screenshot is sent to the Claude API once to be categorized.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(20.dp))
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(6.dp))
    HorizontalDivider()
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun Toggle(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(title: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        if (granted) {
            Text("Granted", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        } else {
            TextButton(onClick = onGrant) { Text("Grant") }
        }
    }
}
