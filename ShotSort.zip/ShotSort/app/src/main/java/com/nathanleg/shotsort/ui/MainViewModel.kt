package com.nathanleg.shotsort.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.nathanleg.shotsort.data.AppDatabase
import com.nathanleg.shotsort.data.CategoryCount
import com.nathanleg.shotsort.data.Prefs
import com.nathanleg.shotsort.data.Screenshot
import com.nathanleg.shotsort.data.Status
import com.nathanleg.shotsort.media.MediaRepo
import com.nathanleg.shotsort.work.Scheduler
import com.nathanleg.shotsort.work.Sorter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class Perms(
    val read: Boolean = false,
    val write: Boolean = false,
    val notifications: Boolean = false,
)

data class Setup(
    val hasApiKey: Boolean = true,
    val moveEnabled: Boolean = true,
    /** null = already decided (or unknown yet). Otherwise how many existing screenshots were found. */
    val backlogCount: Int? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    private val dao = AppDatabase.get(app).dao()
    private val media = MediaRepo(app)
    private val sorter = Sorter(app)

    val query = MutableStateFlow("")
    val category = MutableStateFlow<String?>(null)

    val items: StateFlow<List<Screenshot>> = combine(query, category) { q, c -> q.trim() to c }
        .flatMapLatest { (q, c) -> dao.search(c, q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val counts: StateFlow<List<CategoryCount>> = dao.categoryCounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pending: StateFlow<Int> = dao.countByStatus(Status.PENDING)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val errors: StateFlow<Int> = dao.countByStatus(Status.ERROR)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val running: StateFlow<Boolean> = WorkManager.getInstance(app)
        .getWorkInfosForUniqueWorkFlow("sort")
        .map { list -> list.any { it.state == WorkInfo.State.RUNNING } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val perms = MutableStateFlow(Perms())
    val setup = MutableStateFlow(Setup())

    fun observe(id: Long): Flow<Screenshot?> = dao.observe(id)

    /** Called on every resume: re-check permissions/settings and pick up new screenshots. */
    fun refresh() {
        val notif = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        perms.value = Perms(media.hasReadAccess(), media.hasWriteAccess(), notif)
        setup.value = setup.value.copy(hasApiKey = prefs.apiKey.isNotBlank(), moveEnabled = prefs.moveFiles)
        viewModelScope.launch {
            if (!perms.value.read) return@launch
            if (prefs.backlogCutoff < 0) {
                setup.value = setup.value.copy(backlogCount = media.countUnsorted())
            } else {
                setup.value = setup.value.copy(backlogCount = null)
                sorter.prune()
                if (sorter.discover() > 0 || pending.value > 0) sortNow()
            }
        }
    }

    fun chooseBacklog(sortAll: Boolean) {
        prefs.backlogCutoff = if (sortAll) 0L else System.currentTimeMillis() / 1000
        setup.value = setup.value.copy(backlogCount = null)
        refresh()
    }

    fun sortNow() = Scheduler.sortNow(app)

    fun retryErrors() {
        viewModelScope.launch {
            dao.retryErrors()
            sortNow()
        }
    }

    fun recategorize(item: Screenshot, newCategory: String) {
        viewModelScope.launch { sorter.recategorize(item, newCategory) }
    }

    fun reanalyze(item: Screenshot) {
        viewModelScope.launch {
            dao.update(item.copy(status = Status.PENDING, error = null))
            sortNow()
        }
    }

    fun saveSettings(apiKey: String, model: String, categories: List<String>, move: Boolean, auto: Boolean, notify: Boolean) {
        prefs.apiKey = apiKey
        prefs.model = model
        prefs.categories = categories
        prefs.moveFiles = move
        prefs.autoSort = auto
        prefs.notify = notify
        Scheduler.applySettings(app)
        refresh()
    }
}
