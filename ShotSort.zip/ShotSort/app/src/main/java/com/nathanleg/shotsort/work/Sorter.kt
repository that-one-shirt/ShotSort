package com.nathanleg.shotsort.work

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import com.nathanleg.shotsort.ai.ApiException
import com.nathanleg.shotsort.ai.ClaudeClient
import com.nathanleg.shotsort.data.AppDatabase
import com.nathanleg.shotsort.data.Prefs
import com.nathanleg.shotsort.data.Screenshot
import com.nathanleg.shotsort.data.Status
import com.nathanleg.shotsort.media.MediaRepo
import java.io.IOException

/** The core pipeline: discover -> analyze with Claude -> (optionally) move into a category folder. */
class Sorter(context: Context) {
    private val ctx = context.applicationContext
    private val prefs = Prefs(ctx)
    private val dao = AppDatabase.get(ctx).dao()
    private val media = MediaRepo(ctx)

    fun ready(): Boolean =
        prefs.apiKey.isNotBlank() && prefs.backlogCutoff >= 0 && media.hasReadAccess()

    /** Adds newly found screenshots to the DB as PENDING. Returns how many were added. */
    suspend fun discover(): Int {
        val cutoff = prefs.backlogCutoff
        if (cutoff < 0 || !media.hasReadAccess()) return 0
        val known = dao.allIds().toHashSet()
        val fresh = media.findUnsorted(cutoff).filter { it.id !in known }
        if (fresh.isNotEmpty()) dao.insertAll(fresh)
        return fresh.size
    }

    /** Drops DB rows whose file was deleted outside the app. */
    suspend fun prune() {
        if (!media.hasReadAccess()) return
        val existing = media.existingScreenshotIds()
        val gone = dao.all().filter { row ->
            val currentId = runCatching { ContentUris.parseId(Uri.parse(row.uri)) }.getOrNull()
            currentId == null || currentId !in existing
        }.map { it.id }
        gone.chunked(500).forEach { dao.deleteIds(it) }
    }

    /**
     * Processes everything pending. Throws [ApiException] (auth/quota) or [IOException]
     * (network) to abort the whole run; per-image problems are recorded as ERROR.
     */
    suspend fun runAll(isStopped: () -> Boolean): List<Screenshot> {
        val sorted = mutableListOf<Screenshot>()
        if (!ready()) return sorted
        discover()
        val client = ClaudeClient(prefs.apiKey, prefs.model)
        while (!isStopped()) {
            val batch = dao.pending(10)
            if (batch.isEmpty()) {
                // Something new may have landed while we worked.
                if (discover() == 0) break else continue
            }
            for (item in batch) {
                if (isStopped()) break
                sorted += processOne(item, client)
            }
        }
        return sorted.filter { it.status == Status.DONE }
    }

    suspend fun processOne(item: Screenshot, client: ClaudeClient = ClaudeClient(prefs.apiKey, prefs.model)): Screenshot {
        val categories = prefs.categories.ifEmpty { Prefs.DEFAULT_CATEGORIES }
        val jpeg = try {
            media.jpegForApi(Uri.parse(item.uri))
        } catch (e: Exception) {
            return fail(item, "Couldn't read image: ${e.message}")
        }
        val analysis = try {
            client.analyze(jpeg, categories)
        } catch (e: ApiException) {
            // Bad request for this one image -> mark it; auth/rate/server -> abort run.
            if (e.code == 400 || e.code == 413) return fail(item, e.message ?: "Rejected")
            throw e
        }
        var updated = item.copy(
            status = Status.DONE,
            category = analysis.category,
            title = analysis.title,
            summary = analysis.summary,
            tags = analysis.tags.joinToString(", "),
            text = analysis.text,
            error = null,
            processedAt = System.currentTimeMillis(),
        )
        updated = maybeMove(updated, analysis.category)
        dao.update(updated)
        return updated
    }

    /** Used by the detail screen when the user picks a different category. */
    suspend fun recategorize(item: Screenshot, category: String): Screenshot {
        var updated = item.copy(category = category, status = Status.DONE, error = null)
        updated = maybeMove(updated, category)
        dao.update(updated)
        return updated
    }

    private suspend fun maybeMove(item: Screenshot, category: String): Screenshot {
        if (!prefs.moveFiles || !media.hasWriteAccess()) return item
        return try {
            media.moveToCategory(item, category)
        } catch (e: Exception) {
            item.copy(error = "Sorted, but couldn't move file: ${e.message}")
        }
    }

    private suspend fun fail(item: Screenshot, msg: String): Screenshot {
        val f = item.copy(status = Status.ERROR, error = msg, processedAt = System.currentTimeMillis())
        dao.update(f)
        return f
    }
}
